package com.bitlabs.Arogya;

import java.sql.*;

public class DaoImpl implements DaoInterface{

    Connection con=null;
    DaoImpl(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Prudhvi@995");    
            if(con!=null) {
                System.out.println("connection made sucessfully");
            }
            
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public void patientRegistration(Patient p) {
        // TODO Auto-generated method stub
        
        try {
            PreparedStatement pstmt=con.prepareStatement("insert into patient values (?,?,?,?,?,?,?,?,?,?,?,?)");
            pstmt.setInt(1,p.getId());
            pstmt.setInt(2,p.getAge());
            pstmt.setString(3,p.getName());
            pstmt.setString(4,p.getGender());
            pstmt.setString(5,p.getCity());
            pstmt.setString(6,p.getAddress());
            pstmt.setString(7,p.getGuardian_name());
            pstmt.setString(8,p.getGuardian_address());
            pstmt.setString(9,p.getDateOfAdmission());
            pstmt.setLong(10,p.getAadhar_Card_number());
            pstmt.setLong(11,p.getContact_number());
            pstmt.setLong(12,p.getGuardian_contactNumber());
            
            int i=pstmt.executeUpdate();
            if(i!=0) {
                System.out.println("data saved sucessfully");
            }
            
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }
    public void viewAllPatient()
    {
    	try
    	{
    		Statement st=con.createStatement();
    		ResultSet rs=st.executeQuery("SELECT * FROM Patient");
    		while(rs.next())
    		{
    			System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\t"+rs.getString(7)+"\t"+rs.getString(8)+"\t"+rs.getString(9)+"\t"+rs.getString(10)+"\t"+rs.getString(11)+"\t"+rs.getString(12));
    			
    		}
    		//con.close();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e);
    	}
    }
    public void searchPatientById(int id)
    {
    	try {
    		Statement st=con.createStatement();
    		ResultSet rs=st.executeQuery("SELECT * FROM Patient WHERE id="+id+"");
    		rs.next();
    		System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\t"+rs.getString(7)+"\t"+rs.getString(8)+"\t"+rs.getString(9)+"\t"+rs.getString(10)+"\t"+rs.getString(11)+"\t"+rs.getString(12));
    	}
    	catch(Exception e) {
    		System.out.println(e);
    	}
    }
    public void deletePatientById(int id)
    {
    	try
    	{
    		PreparedStatement pstmt=con.prepareStatement("DELETE FROM PATIENT WHERE id="+id+"");
    		int i=pstmt.executeUpdate();
    		if(i==1)
    		{
    			System.out.println("Patient Record Deleted Successfully");
    		}	
    		else
    		{
    			System.out.println("Error Occur while Deleting");
    		}
    	}
    	catch (Exception e)
    	{
    		System.out.println(e);
    	}	
    }
    public void searchPatientByCity(String city)
    {
    	try
    	{
    		 Statement st=con.createStatement();

             ResultSet rs=st.executeQuery("SELECT * FROM patient WHERE city='"+city+"'");
             while(rs.next())
             {
             System.out.println(rs.getString(1) +"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\t"+rs.getString(7)+"\t"+rs.getString(8)+"\t"+rs.getString(9)+"\t"+rs.getString(10)+"\t"+rs.getString(11)+"\t"+rs.getString(12));
             }
                         
            }
            catch(SQLException e) {
            	e.printStackTrace();
    	}
    }
    public void searchPatientByAgeGroup(int start,int end)
    {
    	try
    	{
   		 Statement st=con.createStatement();
         ResultSet rs=st.executeQuery("SELECT * FROM patient WHERE age>='"+start+"' && age<='"+end+"'");
         while(rs.next())
         {
         System.out.println(rs.getString(1) +"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\t"+rs.getString(7)+"\t"+rs.getString(8)+"\t"+rs.getString(9)+"\t"+rs.getString(10)+"\t"+rs.getString(11)+"\t"+rs.getString(12));
         }
                     
        }
        catch (SQLException e){
    	e.printStackTrace();
    	}
    }
}

    	
